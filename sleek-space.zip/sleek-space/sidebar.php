<?php 
// sidebars are for squares
?>