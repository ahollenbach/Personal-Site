<?php ?>
</div><!-- / end page container, begun in the header -->

<footer class="site-footer" role="contentinfo">
	<div class="site-info container">
		
		<p><a href="http://andrewhollenbach.com/sleek-space" rel="theme">sleek-space</a> theme
			by <a href="http://andrewhollenbach.com" rel="designer">Andrew Hollenbach</a>.
			Inspired by <a href="http://bckmn.com" rel="designer">Joshua Beckman</a>.
		</p>
		
	</div><!-- .site-info -->
</footer><!-- #colophon .site-footer -->

<?php wp_footer(); 
// Allows plugins to insert themselves/scripts/css/files into the footer (here).
?>

</body>
</html>
